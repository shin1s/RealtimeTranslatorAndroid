# リアルタイム通訳（Android）

日本語・英語・中国語・韓国語など14言語に対応したAndroid向け通訳アプリです。

## 主な機能

- 🎙️ 音声認識（Android SpeechRecognizer）
- 🔊 翻訳結果の音声読み上げ（Android TextToSpeech）
- 🗣️ 交互通訳モード
- 🔄 A→B、B→Aを自動切替
- 📜 会話履歴
- 🌐 14言語対応
- 📱 Android 8.0（API 26）以降

## APKを自動生成する方法（簡単）

このプロジェクトには GitHub Actions の設定が入っています。

1. GitHubで新しいリポジトリを作成します。
2. このフォルダの中身をリポジトリへアップロードします。
3. GitHubの「Actions」→「Build Android APK」を開きます。
4. 「Run workflow」を押します。
5. ビルド完了後、「Artifacts」から `realtime-translator-debug-apk` をダウンロードします。
6. ZIPを展開すると `app-debug.apk` が入っています。
7. AndroidスマートフォンへAPKを送り、インストールします。

GitHub ActionsはAndroid SDKとGradleを自動で準備するため、PC側にAndroid StudioをインストールしなくてもAPKを作れます。

## Android Studioで作る場合

- JDK 17
- Android SDK Platform 35
- Build Tools 35.0.0
- Gradle 8.9以上

プロジェクトをAndroid Studioで開き、`assembleDebug` を実行してください。

生成先：

`app/build/outputs/apk/debug/app-debug.apk`

## 翻訳について

初期設定ではLibreTranslate互換の公開エンドポイントを使用しています。
公開サービスは混雑・レート制限・停止などがあり得るため、安定運用では自分のLibreTranslateサーバーまたは別の翻訳APIへ変更してください。

## 注意

音声認識はAndroid端末に搭載された音声認識サービスに依存します。端末やAndroidの設定によって対応言語・認識精度が異なります。


### 翻訳サービスについて
この版はAPIキー不要のMyMemory Translation APIを使用します。無料利用にはサービス側の利用上限があります。
