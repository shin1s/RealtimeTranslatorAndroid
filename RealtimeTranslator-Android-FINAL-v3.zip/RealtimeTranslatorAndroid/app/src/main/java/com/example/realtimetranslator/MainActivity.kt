package com.example.realtimetranslator

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class Lang(val label: String, val speech: String, val api: String)
data class Turn(val speaker: String, val original: String, val translated: String)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var listening = false
    private var interpreterActive = false
    private var currentSpeaker = "A"
    private var sourceLang by mutableStateOf(Lang("日本語", "ja-JP", "ja"))
    private var targetLang by mutableStateOf(Lang("English", "en-US", "en"))

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val requestMic = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListening()
        else setUiStatus("マイクの許可が必要です")
    }

    private val _status = mutableStateOf("待機中")
    private val _interim = mutableStateOf("")
    private val _input = mutableStateOf("")
    private val _output = mutableStateOf("")
    private val _history = mutableStateListOf<Turn>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setupRecognizer()

        setContent {
            MaterialTheme {
                TranslatorScreen(
                    status = _status.value,
                    interim = _interim.value,
                    input = _input.value,
                    output = _output.value,
                    history = _history,
                    interpreterActive = interpreterActive,
                    speaker = currentSpeaker,
                    onStartStop = { toggleInterpreter() },
                    onTranslate = { translateCurrent() },
                    onSpeak = { speakOutput() },
                    onClear = {
                        _input.value = ""
                        _output.value = ""
                        _interim.value = ""
                        _history.clear()
                    },
                    sourceLang = sourceLang,
                    targetLang = targetLang,
                    onInputChange = { _input.value = it },
                    onSourceChange = { sourceLang = it },
                    onTargetChange = { targetLang = it }
                )
            }
        }
    }

    override fun onDestroy() {
        interpreterActive = false
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        scope.cancel()
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts.language = Locale.US
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setUiStatus("この端末では音声認識を利用できません")
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { setUiStatus("聞き取り中…") }
            override fun onBeginningOfSpeech() { setUiStatus("話してください") }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { setUiStatus("処理中…") }
            override fun onError(error: Int) {
                listening = false
                if (interpreterActive) {
                    // SpeechRecognizer is not guaranteed to stay continuous on Android.
                    // Retry after a short pause, except when the user stopped the interpreter.
                    scope.launch {
                        delay(500)
                        if (interpreterActive) startListening()
                    }
                } else setUiStatus("待機中")
            }
            override fun onResults(results: Bundle?) {
                listening = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (text.isNotBlank()) {
                    _input.value = text
                    translateCurrent(autoContinue = interpreterActive)
                } else if (interpreterActive) {
                    startListening()
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                _interim.value = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun toggleInterpreter() {
        if (interpreterActive) {
            interpreterActive = false
            recognizer?.stopListening()
            listening = false
            setUiStatus("通訳停止")
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
                requestMic.launch(Manifest.permission.RECORD_AUDIO)
                return
            }
            interpreterActive = true
            currentSpeaker = "A"
            startListening()
        }
    }

    private fun startListening() {
        if (!interpreterActive && listening) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestMic.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        if (recognizer == null) setupRecognizer()
        try {
            recognizer?.cancel()
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, sourceLang.speech)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, sourceLang.speech)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            listening = true
            _interim.value = ""
            recognizer?.startListening(intent)
            setUiStatus("聞き取り中…")
        } catch (e: Exception) {
            listening = false
            setUiStatus("音声認識を開始できません: ${e.message}")
        }
    }

    private fun translateCurrent(autoContinue: Boolean = false) {
        val text = _input.value.trim()
        if (text.isEmpty()) {
            if (autoContinue) startListening()
            return
        }
        val from = sourceLang
        val to = targetLang
        scope.launch {
            setUiStatus("翻訳中…")
            try {
                val translated = withContext(Dispatchers.IO) { LibreTranslate.translate(text, from.api, to.api) }
                _output.value = translated
                _history.add(0, Turn(currentSpeaker, text, translated))
                _interim.value = ""
                if (autoContinue && interpreterActive) {
                    speakAndContinue(translated, to.speech)
                } else setUiStatus("翻訳完了")
            } catch (e: Exception) {
                _output.value = "翻訳エラー: ${e.message}"
                setUiStatus("翻訳エラー")
                if (autoContinue && interpreterActive) startListening()
            }
        }
    }

    private fun speakAndContinue(text: String, language: String) {
        if (!ttsReady) {
            switchSpeakerAndListen()
            return
        }
        val locale = Locale.forLanguageTag(language)
        tts.language = locale
        tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                scope.launch(Dispatchers.Main) {
                    if (interpreterActive) switchSpeakerAndListen()
                }
            }
            override fun onError(utteranceId: String?) {
                scope.launch(Dispatchers.Main) {
                    if (interpreterActive) switchSpeakerAndListen()
                }
            }
        })
        setUiStatus("翻訳音声を再生中…")
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "turn_${System.currentTimeMillis()}")
    }

    private fun switchSpeakerAndListen() {
        currentSpeaker = if (currentSpeaker == "A") "B" else "A"
        // Bidirectional mode: the language pair reverses for the next speaker.
        val old = sourceLang
        sourceLang = targetLang
        targetLang = old
        _input.value = ""
        _output.value = ""
        startListening()
    }

    private fun translateCurrent() = translateCurrent(autoContinue = false)

    private fun speakOutput() {
        if (!_output.value.isNullOrBlank() && ttsReady) {
            tts.language = Locale.forLanguageTag(targetLang.speech)
            tts.speak(_output.value, TextToSpeech.QUEUE_FLUSH, null, "manual_${System.currentTimeMillis()}")
        }
    }

    private fun setUiStatus(s: String) { _status.value = s }
}

object LibreTranslate {
    private const val ENDPOINT = "https://libretranslate.com/translate"

    fun translate(text: String, source: String, target: String): String {
        val url = URL(ENDPOINT)
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 15_000
        connection.readTimeout = 30_000
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8")

        val body = JSONObject().apply {
            put("q", text)
            put("source", source)
            put("target", target)
            put("format", "text")
        }.toString()

        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        connection.disconnect()
        if (code !in 200..299) throw Exception(response.take(180))
        return JSONObject(response).optString("translatedText", "").ifBlank {
            throw Exception("翻訳結果が空です")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TranslatorScreen(
    status: String,
    interim: String,
    input: String,
    output: String,
    history: List<Turn>,
    interpreterActive: Boolean,
    speaker: String,
    onStartStop: () -> Unit,
    onTranslate: () -> Unit,
    onSpeak: () -> Unit,
    onClear: () -> Unit,
    sourceLang: Lang,
    targetLang: Lang,
    onInputChange: (String) -> Unit,
    onSourceChange: (Lang) -> Unit,
    onTargetChange: (Lang) -> Unit
) {
    val languages = listOf(
        Lang("日本語", "ja-JP", "ja"), Lang("English", "en-US", "en"),
        Lang("中文", "zh-CN", "zh"), Lang("한국어", "ko-KR", "ko"),
        Lang("Español", "es-ES", "es"), Lang("Français", "fr-FR", "fr"),
        Lang("Deutsch", "de-DE", "de"), Lang("Italiano", "it-IT", "it"),
        Lang("Português", "pt-BR", "pt"), Lang("ไทย", "th-TH", "th"),
        Lang("Tiếng Việt", "vi-VN", "vi"), Lang("Bahasa Indonesia", "id-ID", "id"),
        Lang("العربية", "ar-SA", "ar"), Lang("हिन्दी", "hi-IN", "hi")
    )

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Column {
                    Text("リアルタイム通訳", fontWeight = FontWeight.Bold)
                    Text(status, style = MaterialTheme.typography.labelSmall)
                }
            })
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("言語", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            LanguageDropdown("自分/話者A", sourceLang, languages, onSourceChange)
                            LanguageDropdown("相手/話者B", targetLang, languages, onTargetChange)
                        }
                        Text(
                            if (interpreterActive) "現在の話者: $speaker　次の発話を自動で反対言語へ通訳します"
                            else "通訳モードを開始すると、交互に自動通訳します",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Button(
                            onClick = onStartStop,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                if (interpreterActive) Icons.Default.Stop else Icons.Default.Mic,
                                contentDescription = null
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(if (interpreterActive) "通訳を停止" else "🎧 通訳開始")
                        }
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = input,
                    onValueChange = onInputChange,
                    label = { Text("認識した音声") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp),
                    minLines = 4
                )
            }

            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("翻訳結果", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            IconButton(onClick = onSpeak) {
                                Icon(Icons.Default.VolumeUp, contentDescription = "再生")
                            }
                        }
                        Text(
                            if (output.isBlank()) "ここに翻訳結果が表示されます。" else output,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        if (interim.isNotBlank()) {
                            Text("認識中: $interim", style = MaterialTheme.typography.labelSmall)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = onTranslate) { Text("翻訳") }
                            OutlinedButton(onClick = onClear) {
                                Icon(Icons.Default.Delete, contentDescription = null)
                                Spacer(Modifier.width(4.dp))
                                Text("消去")
                            }
                        }
                    }
                }
            }

            item { Text("会話履歴", fontWeight = FontWeight.Bold) }
            items(history) { turn ->
                Card {
                    Column(Modifier.padding(14.dp)) {
                        Text("話者 ${turn.speaker}", style = MaterialTheme.typography.labelSmall)
                        Text(turn.original)
                        Text(turn.translated, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun RowScope.LanguageDropdown(
    label: String,
    selected: Lang,
    languages: List<Lang>,
    onSelect: (Lang) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box(Modifier.weight(1f)) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selected.label)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            languages.forEach { lang ->
                DropdownMenuItem(
                    text = { Text(lang.label) },
                    onClick = { onSelect(lang); expanded = false }
                )
            }
        }
    }
}
